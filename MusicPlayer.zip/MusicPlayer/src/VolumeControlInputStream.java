import java.io.*;

public class VolumeControlInputStream extends BufferedInputStream {
    private float volume;

    public VolumeControlInputStream(InputStream in, float volume) {
        super(in);
        this.volume = volume;
    }

    public void setVolume(float volume) {
        this.volume = volume;
    }

    @Override
    public synchronized int read(byte[] b, int off, int len) throws IOException {
        int bytesRead = super.read(b, off, len);
        if (bytesRead > 0) {
            for (int i = off; i < off + bytesRead; i += 2) {
                if (i + 1 < b.length) {
                    short sample = (short) ((b[i + 1] & 0xFF) << 8 | (b[i] & 0xFF));
                    sample = (short) (sample * volume);
                    b[i] = (byte) (sample & 0xFF);
                    b[i + 1] = (byte) ((sample >> 8) & 0xFF);
                }
            }
        }
        return bytesRead;
    }
}